#!/bin/sh
./autogen.sh  $@
